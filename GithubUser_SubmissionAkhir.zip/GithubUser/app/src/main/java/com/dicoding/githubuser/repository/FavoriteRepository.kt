package com.dicoding.githubuser.repository

import androidx.lifecycle.LiveData
import com.dicoding.githubuser.data.retrofit.ApiService
import com.dicoding.githubuser.database.FavoriteDao
import com.dicoding.githubuser.database.FavoriteUser
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FavoriteRepository private constructor(
    private val apiService: ApiService,
    private val favoriteDao: FavoriteDao,
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
) {
    fun getGithub(query: String) = apiService.getGithub(query)

    fun getDetailUser(userDetail: String) = apiService.getDetailUser(userDetail)

    fun getFollowers(userFollower: String) = apiService.getFollowers(userFollower)

    fun getFollowing(userFollowing: String) = apiService.getFollowing(userFollowing)

    fun getAllFavorites(): LiveData<List<FavoriteUser>> = favoriteDao.getAllFavorite()

    fun setFavoriteUser(username: String) = favoriteDao.getFavoriteUserByUsername(username)

    fun insertFavorite(favoriteUser: FavoriteUser) {
        executorService.execute { favoriteDao.insert(favoriteUser) }
    }

    fun deleteFavorite(favoriteUser: FavoriteUser) {
        executorService.execute { favoriteDao.delete(favoriteUser) }
    }

    companion object {
        @Volatile
        private var instance: FavoriteRepository? = null

        fun getInstance(
            apiService: ApiService, favoriteDao: FavoriteDao
        ): FavoriteRepository = instance ?: synchronized(this) {
            instance ?: FavoriteRepository(apiService, favoriteDao)
        }.also { instance = it }
    }
}