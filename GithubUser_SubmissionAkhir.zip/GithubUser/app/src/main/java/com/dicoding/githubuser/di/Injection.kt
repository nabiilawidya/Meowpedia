package com.dicoding.githubuser.di

import com.dicoding.githubuser.database.FavoriteDatabase
import android.content.Context
import com.dicoding.githubuser.data.retrofit.ApiConfig
import com.dicoding.githubuser.repository.FavoriteRepository

object Injection {
    fun provideRepository(context: Context): FavoriteRepository {
        val apiService = ApiConfig.getApiService()
        val database = FavoriteDatabase.getDatabase(context)
        val dao = database.favoriteDao()
        return FavoriteRepository.getInstance(apiService, dao)
    }
}