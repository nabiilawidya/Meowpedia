package com.dicoding.githubuser.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.githubuser.R
import com.dicoding.githubuser.data.response.DetailUserResponse
import com.dicoding.githubuser.database.FavoriteUser
import com.dicoding.githubuser.databinding.ActivityDetailBinding
import com.dicoding.githubuser.ui.viewmodel.DetailViewModel
import com.dicoding.githubuser.ui.viewmodel.FavoriteViewModel
import com.dicoding.githubuser.ui.viewmodel.ViewModelFactory
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    private val detailViewModel by viewModels<DetailViewModel>() {
        ViewModelFactory.getInstance(this)
    }
    private val favoriteViewModel by viewModels<FavoriteViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var favoriteUser: FavoriteUser
    private var favorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val username = intent.getStringExtra(EXTRA_USER) ?: ""

        if (username.isNotBlank()) {
            detailViewModel.findDetail(username)
        }
        detailViewModel.detail.observe(this) { user ->
            setUser(user)
            favoriteUser = FavoriteUser(
                user.login,
                user.avatarUrl
            )
        }

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        binding.viewPager.adapter = sectionsPagerAdapter
        sectionsPagerAdapter.username = username

        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter

        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        favoriteViewModel.isFavoriteUser(username).observe(this) { user ->
            favorite = user != null
            setIcon()
        }

        favoriteViewModel.isFavoriteUser(username).observe(this) { user ->
            favorite == true
            setIcon()
        }

        binding.btnFavorite.setOnClickListener {
            if (!favorite) {
                favoriteViewModel.insertFavoriteUser(favoriteUser)
            } else {
                favoriteViewModel.deleteFavoriteUser(favoriteUser)
            }
        }
    }

    private fun setUser(user: DetailUserResponse) {
        binding.apply {
            tvUsername.text = user.login
            tvUsername2.text = user.name
            tvFollowers.text = "${user.followers} Followers"
            tvFollowing.text = "${user.following} Following"
            Glide.with(this@DetailActivity)
                .load(user.avatarUrl)
                .into(ivProfile)
        }
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar2.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun setIcon() {
        if (favorite) {
            binding.btnFavorite.setImageResource(R.drawable.ic_favorite_fill)
        } else {
            binding.btnFavorite.setImageResource(R.drawable.ic_favorite_borderline)
        }
    }

    companion object {
        const val EXTRA_USER = "extra_user"
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }
}