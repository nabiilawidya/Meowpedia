package com.dicoding.githubuser.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser.database.FavoriteUser
import com.dicoding.githubuser.repository.FavoriteRepository

class FavoriteViewModel(private val favoriteRepository: FavoriteRepository) : ViewModel() {

    private val _favorite = MutableLiveData<Boolean>()
    val favorite: LiveData<Boolean> = _favorite

    fun getAllFavoriteUser() = favoriteRepository.getAllFavorites()

    fun insertFavoriteUser(username: FavoriteUser) {
        favoriteRepository.insertFavorite(username)
        _favorite.value = true
    }

    fun deleteFavoriteUser(username: FavoriteUser) {
        favoriteRepository.deleteFavorite(username)
        _favorite.value = true
    }

    fun isFavoriteUser(username: String) = favoriteRepository.setFavoriteUser(username)
}